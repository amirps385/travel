<template>
  <div class="p-6">
    <h1 class="text-2xl font-semibold">Admin Panel</h1>
    <p class="mt-2 text-gray-600">Use the sidebar to navigate admin sections.</p>
    <div class="mt-6">
      <NuxtLink to="/admin/dashboard" class="px-4 py-2 bg-blue-600 text-white rounded">Go to Dashboard</NuxtLink>
    </div>
  </div>
</template>

<script setup>
</script>

<style scoped></style>
