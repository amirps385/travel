import { defineEventHandler } from 'h3'
export default defineEventHandler(()=> [{ name: 'Serengeti', slug: 'serengeti' }])
