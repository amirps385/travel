import { defineEventHandler } from 'h3'
export default defineEventHandler(()=> [{ title: 'Sample Tour', slug: 'sample-tour' }])
